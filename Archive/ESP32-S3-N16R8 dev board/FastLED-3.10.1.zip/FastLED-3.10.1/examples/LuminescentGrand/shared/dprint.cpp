

#include "dprint.h"

bool is_debugging = false;